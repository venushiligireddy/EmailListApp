﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SBILibrary.Objects;

public partial class ViewAssociates : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label headerLabel = this.Master.FindControl("lblPageTitle") as Label;
        if (headerLabel != null)
            headerLabel.Text = "Associates";
        if (!IsPostBack)
        {

            var allUsers = _emailListManager.GetAllUsers();
            AssociatesRepeater.DataSource = allUsers;
            AssociatesRepeater.DataBind();
        }
    }

    protected void AssociatesRepeater_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            UserInfo userInfo = e.Item.DataItem as UserInfo;
            if (!userInfo.IsAnyGroupAssigned)
            {
                LinkButton linkButton = e.Item.FindControl("ViewGroupsLinkButton") as LinkButton;
                linkButton.Visible = false;
            }
        }
    }

    protected void AssociatesRepeater_ItemCommand(object sender, RepeaterCommandEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            LinkButton linkButton = e.Item.FindControl("ViewGroupsLinkButton") as LinkButton;
            string dataItem = Convert.ToString(linkButton.Attributes["data-item"]);
            int associateId = 0;
            if (int.TryParse(dataItem, out associateId))
            {
                HiddenField assocNameHiddenField = e.Item.FindControl("AssocNameHiddenField") as HiddenField;
                if (assocNameHiddenField != null)
                    GroupHeaderLiteral.Text = "All Groups for " + assocNameHiddenField.Value;
                else
                    GroupHeaderLiteral.Text = "All Groups";
                ShowGroups(associateId);
            }
        }
    }

    private void ShowGroups(int associateId)
    {
        var userAllGroups = _emailListManager.GetUserAllGroups(associateId);
        if (userAllGroups.Count() > 0)
        {
            NoDataLiteral.Text = String.Empty;
            GroupsRepeater.Visible = true;
            GroupsRepeater.DataSource = userAllGroups;
            GroupsRepeater.DataBind();
        }
        else
        {
            GroupsRepeater.Visible = false;
            NoDataLiteral.Text = "No groups found.";
        }
        ScriptManager.RegisterStartupScript(this, this.GetType(), "button_click", "showOnlyGroupModal();", true);
    }
}