﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SBILibrary.Objects;
using System.Data;
using System.Configuration;

public partial class AddGroup : BasePage
{
    protected void Page_Init(object sender, EventArgs e)
    {
        
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        Label headerLabel = this.Master.FindControl("lblPageTitle") as Label;
        if (headerLabel != null)
            headerLabel.Text = "Groups";
        if (!IsPostBack)
        {
            LoadAllGroups();
            LoadAllApplications();
            LoadAllUsers();

            string id = Request.QueryString["id"];
            if (!String.IsNullOrEmpty(id))
            {
                int groupId = 0;
                if (int.TryParse(id, out groupId))
                {
                    IsReadOnlyPage.Value = "1";
                    ShowGroupDetails(groupId, true);
                }
            }
        }
    }

    private void LoadAllGroups()
    {
        IEnumerable<GroupInfo> allUserGroups = _emailListManager.GetAllUserGroups();        
        GroupsRepeater.DataSource = allUserGroups;
        GroupsRepeater.DataBind();
        GroupsListBox.DataSource = allUserGroups;
        GroupsListBox.DataTextField = "GroupKey";
        GroupsListBox.DataValueField = "ID";
        GroupsListBox.DataBind();
        //allUserGroups.Select(
    }

    private void LoadAllApplications()
    {
        IEnumerable<ApplicationInfo> allApplications = _emailListManager.GetAllApplications(true);
        AppsListBox.DataSource = allApplications.OrderBy(a => a.Name);
        AppsListBox.DataTextField = "AppKey";
        AppsListBox.DataValueField = "AppId";
        AppsListBox.DataBind();
    }

    private void LoadAllUsers()
    {
        IEnumerable<UserInfo> allUsers = _emailListManager.GetAllUsers();
        AssociatesListBox.DataSource = allUsers;
        AssociatesListBox.DataTextField = "DisplayName";
        AssociatesListBox.DataValueField = "Id";
        AssociatesListBox.DataBind();
    }    

    protected void GroupsRepeater_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
               
    }

    protected void GroupsRepeater_ItemCommand(object sender, RepeaterCommandEventArgs e)
    {        
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            LinkButton linkButton = e.Item.FindControl("GroupNameLinkButton") as LinkButton;
            string dataItem = Convert.ToString(linkButton.Attributes["data-item"]);
            int GroupId = 0;
            if (int.TryParse(dataItem, out GroupId))
            {
                ShowGroupDetails(GroupId, false);
            }
        }
    }

    private void ShowGroupDetails(int GroupId, bool isPageLoad)
    {
        GroupHeaderLiteral.Text = "Edit Group";
        GroupIdHiddenField.Value = GroupId.ToString();
        GroupInfo groupInfo = _emailListManager.GetUserGroupDetails(GroupId);
        GroupNameTextBox.Text = groupInfo.Name;
        GroupKeyTextBox.Text = groupInfo.GroupKey;
        GroupDescTextBox.Text = groupInfo.Description;
        CanReadCheckBox.Checked = groupInfo.CanRead;
        CanWriteCheckBox.Checked = groupInfo.CanWrite;
        CanDeleteCheckBox.Checked = groupInfo.CanDelete;
        IsActiveCheckBox.Checked = groupInfo.IsEnabled;

        if (!String.IsNullOrEmpty(groupInfo.AppIds))
        {
            string[] selectedAppIds = groupInfo.AppIds.Split(',');
            foreach (string id in selectedAppIds)
            {
                ListItem item = AppsListBox.Items.FindByValue(id);
                if (item != null)
                    item.Selected = true;
            }
        }
        if (!String.IsNullOrEmpty(groupInfo.UserIds))
        {
            string[] selectedUserIds = groupInfo.UserIds.Split(',');
            foreach (string id in selectedUserIds)
            {
                ListItem item = AssociatesListBox.Items.FindByValue(id);
                if (item != null)
                    item.Selected = true;
            }
        }
        ListItem listItem = GroupsListBox.Items.FindByValue(GroupId.ToString());
        if (listItem != null)
            GroupsListBox.Items.Remove(listItem);
        if (!String.IsNullOrEmpty(groupInfo.GroupIds))
        {
            string[] selectedGroupIds = groupInfo.GroupIds.Split(',');
            foreach (string id in selectedGroupIds)
            {
                ListItem item = GroupsListBox.Items.FindByValue(id);
                if (item != null)
                    item.Selected = true;
            }
        }

        if(isPageLoad)
            ScriptManager.RegisterStartupScript(this, this.GetType(), "button_click", "showOnlyGroupModal();", true);
        else
            ScriptManager.RegisterStartupScript(this, this.GetType(), "button_click", "showGroupModal();", true);
    }

    protected void SaveGroupButton_Click(object sender, EventArgs e)
    {
        Output result;
        GroupInfo groupInfo = new GroupInfo();
        groupInfo.Name = GroupNameTextBox.Text;
        groupInfo.GroupKey = GroupKeyTextBox.Text.ToUpper();
        groupInfo.Description = GroupDescTextBox.Text;
        groupInfo.CreatedBy = CurrentUserName;
        groupInfo.CanRead = CanReadCheckBox.Checked;
        groupInfo.CanWrite = CanWriteCheckBox.Checked;
        groupInfo.CanDelete = CanDeleteCheckBox.Checked;
        groupInfo.IsEnabled = IsActiveCheckBox.Checked;
        groupInfo.AppIds = GetCommaSeparatedString(AppsListBox);
        groupInfo.UserIds = GetCommaSeparatedString(AssociatesListBox);
        groupInfo.GroupIds = GetCommaSeparatedString(GroupsListBox);
        if (!String.IsNullOrEmpty(GroupIdHiddenField.Value))
        {
            // perform update operation.
            groupInfo.Id = Convert.ToInt32(GroupIdHiddenField.Value);
            groupInfo.ModifiedBy = CurrentUserName;
            result = _emailListManager.UpdateUserGroup(groupInfo);
        }
        else
        {
            result = _emailListManager.InsertUserGroup(groupInfo);
        }

        if (result == Output.Success)
        {            
            CancelButton_Click(sender, e);
        }
        else if (result == Output.AlreadyExist)
        {
            MessageHiddenField.Value = "This GROUP KEY is not available";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "button_click", "showGroupModal();", true);
        }
    }

    protected void CancelButton_Click(object sender, EventArgs e)
    {
        GroupHeaderLiteral.Text = "Add Group";
        GroupIdHiddenField.Value = String.Empty;        
        GroupNameTextBox.Text = String.Empty;
        GroupKeyTextBox.Text = String.Empty;
        GroupDescTextBox.Text = String.Empty;
        CanReadCheckBox.Checked = false;
        CanWriteCheckBox.Checked = false;
        CanDeleteCheckBox.Checked = false;
        IsActiveCheckBox.Checked = false;
        MessageHiddenField.Value = "";               
        AppsListBox.ClearSelection();
        AssociatesListBox.ClearSelection();
        LoadAllGroups();
        ScriptManager.RegisterStartupScript(this, this.GetType(), "button_click2", "closeGroupModal();", true);
    }

    private string GetCommaSeparatedString(ListBox listBox)
    {
        string retVal = String.Empty;
        int[] selIndices = listBox.GetSelectedIndices();
        foreach (int i in selIndices)
        {
            retVal += listBox.Items[i].Value + ",";            
        }        
        return retVal.TrimEnd(',');
    }
}