﻿$(document).ready(function () {

    $('.firstName').focusout(function () {
        var firstName = $('.firstName').val();
        var lastName = $('.lastName').val();

        if ((jQuery.trim(firstName).length != 0) && (jQuery.trim(lastName).length != 0)) {
            $('.shortName').val(firstName + ' ' + lastName);
        }
        else if ((jQuery.trim(firstName).length == 0) && (jQuery.trim(lastName).length != 0)) {
            $('.shortName').val(lastName);
        }
        else if ((jQuery.trim(firstName).length != 0) && (jQuery.trim(lastName).length == 0)) {
            $('.shortName').val(firstName);
        }

    });

    $('.lastName').focusout(function () {
        var firstName = $('.firstName').val();
        var lastName = $('.lastName').val();

        if ((jQuery.trim(firstName).length != 0) && (jQuery.trim(lastName).length != 0)) {
            $('.shortName').val(firstName + ' ' + lastName);
        }
        else if ((jQuery.trim(firstName).length == 0) && (jQuery.trim(lastName).length != 0)) {
            $('.shortName').val(lastName);
        }
        else if ((jQuery.trim(firstName).length != 0) && (jQuery.trim(lastName).length == 0)) {
            $('.shortName').val(firstName);
        }
    });


    /*Corners on menu*/
    $('#menu a:hover, #menu .current_page_item a').corner("top");
    $('#menu a').hover(function () { $(this).corner("top"); });
});