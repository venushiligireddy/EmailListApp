﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Configuration;
using SBILibrary.Objects;

[Serializable]
public partial class _Default : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            IEnumerable<DepartmentInfo> departmentList = _emailListManager.GetAllDepartments();
            DepartmentsDropDownList.DataSource = departmentList;
            DepartmentsDropDownList.DataTextField = "Name";
            DepartmentsDropDownList.DataValueField = "Id";
            DepartmentsDropDownList.DataBind();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        UserInfo user = new UserInfo();
        user.Email = TextBox3.Text.Trim();
        user.FirstName = TextBox1.Text.Trim();
        user.LastName = TextBox2.Text.Trim();
        if (String.IsNullOrEmpty(TextBox4.Text.Trim()))
            user.ShortName = user.FirstName + " " + user.LastName;
        else
            user.ShortName = TextBox4.Text.Trim();
        user.CreatedBy = CurrentUserName;
        user.DeptId = Convert.ToInt32(DepartmentsDropDownList.SelectedValue);
        user.UserName = UserNameTextBox.Text.Trim();
        
        Output output = _emailListManager.InsertAssociate(user);
        if (output == Output.Success)
            Label6.Text = "Associate has been Added";
        else if (output == Output.Failed)
        {
            Label6.Text = "Associate was not Added";
            Label6.ForeColor = System.Drawing.ColorTranslator.FromHtml("#990033");
        }
        else if (output == Output.EmailAlreadyExist)
        {
            Label6.Text = "Error: Email already exists";
            Label6.ForeColor = System.Drawing.ColorTranslator.FromHtml("#990033");
        }
        else if (output == Output.ShortNameAlreadyExist)
        {
            Label6.Text = "Error: Short Name already exists";
            Label6.ForeColor = System.Drawing.ColorTranslator.FromHtml("#990033");
        }
        else if (output == Output.AlreadyExist)
        {
            Label6.Text = "Error: User Name already exists";
            Label6.ForeColor = System.Drawing.ColorTranslator.FromHtml("#990033");
        }
        
        //Label6.ForeColor = new System.Drawing.Color();
        //string connetionString = WebConfigurationManager.ConnectionStrings["EmailListConnectionString"].ConnectionString.ToString();
        //SqlConnection cnn;
        //cnn = new SqlConnection(connetionString);

        ///*passing null for empty textbox*/
        //string shortNameValue = TextBox4.Text;
        //if (string.IsNullOrEmpty(shortNameValue))
        //{
        //    shortNameValue = null;
        //}


        //try
        //{

        //    using (SqlCommand cmd = new SqlCommand("spAddAssociateForWebsite", cnn))
        //    {
        //        cmd.CommandType = CommandType.StoredProcedure;

        //        cmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = TextBox3.Text;
        //        cmd.Parameters.Add("@FirstName", SqlDbType.VarChar).Value = TextBox1.Text;
        //        cmd.Parameters.Add("@LastName", SqlDbType.VarChar).Value = TextBox2.Text;
        //        cmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = shortNameValue;


        //        cmd.Parameters.Add("@return_value", SqlDbType.Int, 4).Direction = ParameterDirection.ReturnValue;

        //        cnn.Open();
        //        cmd.ExecuteNonQuery();
        //        cnn.Close();




        //        if (Convert.ToInt32(cmd.Parameters["@return_value"].Value) == 0)
        //        {
        //            Label6.Text = "Associate has been Added";
        //            TextBox1.Text = String.Empty;
        //            TextBox2.Text = String.Empty;
        //            TextBox3.Text = String.Empty;
        //            TextBox4.Text = String.Empty;
        //        }
        //        else if (Convert.ToInt32(cmd.Parameters["@return_value"].Value) == 99)
        //        {
        //            Label6.Text = "Error: Email already exists";
        //            Label6.ForeColor = System.Drawing.ColorTranslator.FromHtml("#990033");
        //        }
        //        else if (Convert.ToInt32(cmd.Parameters["@return_value"].Value) == 100)
        //        {
        //            Label6.Text = "Email Error: Use .com, .net or .org";
        //            Label6.ForeColor = System.Drawing.ColorTranslator.FromHtml("#990033");
        //        }
        //        else if (Convert.ToInt32(cmd.Parameters["@return_value"].Value) == 101)
        //        {
        //            Label6.Text = "Error: Short Name already exists";
        //            Label6.ForeColor = System.Drawing.ColorTranslator.FromHtml("#990033");
        //        }
        //        else
        //        {
        //            Label6.Text = "Associate was not Added";
        //            Label6.ForeColor = System.Drawing.ColorTranslator.FromHtml("#990033");
        //        }

        //    }

        //}
        //catch (Exception ex)
        //{
        //    Label5.Text = "<b>Error occured adding Associate--></b>" + ex.ToString();
        //}        
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        
    }



    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {
        
    }
}