﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.HtmlControls;
using SBILibrary.Objects;

[Serializable]
public partial class MasterPage : EmailListMasterPage
{

    public string Firstname;
    public string Lastname;


    public string home = "current_page_item";
    public string updtAssoc = null;
    public string viewAssocList = null;
    public string addList = null;
    public string editList = null;
    public string updtList = null;
    public string appsHome = null;
    public string groupsHome = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        /*authentication*/
        string groupKey = ConfigurationManager.AppSettings["EmailListWebSiteGroupKey"];
        string adminGroupKey = ConfigurationManager.AppSettings["EmailListWebSiteAdminGroupKey"];
        UserInfo _userInfo = CurrentUserInfo;
        if (_userInfo == null || _userInfo.AssignedGroups.Where(p => p.GroupKey == groupKey).Count() < 1)
        {
            Server.Transfer("Unauthorized.aspx");
            return;
        }

        if (_userInfo.AssignedGroups.Where(p => p.GroupKey == adminGroupKey).Count() < 1)
        {            
            string absPath = Page.Request.Url.AbsolutePath;
            if (absPath.EndsWith("AddApplication.aspx") || absPath.EndsWith("AddGroup.aspx") || absPath.EndsWith("ViewAssociates.aspx"))
            {
                Server.Transfer("Unauthorized.aspx");
                return;
            }
            else
                AddApplicationLink.Visible = false;
        }

        /*authentication finishes*/


        string sPath = System.Web.HttpContext.Current.Request.Url.AbsolutePath;
        System.IO.FileInfo oInfo = new System.IO.FileInfo(sPath);
        string sRet = oInfo.Name;

        if (sRet == "AddAssociate.aspx")
        {
            home = "current_page_item";
            lblPageTitle.Text = "Add Associate";
        }
        else if (sRet == "EditAssociates.aspx")
        {
            updtAssoc = "current_page_item"; home = null;
            lblPageTitle.Text = "Edit Associates";
        }
        else if (sRet == "AssociateLists.aspx")
        {
            viewAssocList = "current_page_item"; home = null;
            lblPageTitle.Text = "Associate Lists";
        }
        else if (sRet == "AddAList.aspx")
        {
            addList = "current_page_item"; home = null;
            lblPageTitle.Text = " Add a List";
        }
        else if (sRet == "EditList.aspx")
        {
            editList = "current_page_item"; home = null;
            lblPageTitle.Text = "Edit List";
        }
        else if (sRet == "UpdateList.aspx")
        {
            updtList = "current_page_item"; home = null;
            lblPageTitle.Text = "Update List";
        }
        else if (sRet == "AddApplication.aspx" || sRet == "AddGroup.aspx" || sRet == "ViewAssociates.aspx")
        {
            appsHome = "current_page_item"; home = null;
            AddApplicationLink.Attributes.Add("class", appsHome);
        }
       
    }


    protected void imgBanner_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AddAssociate.aspx");
    }
}
