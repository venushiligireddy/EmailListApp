﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data;
using System.Data.SqlClient;

[Serializable]
public partial class EditList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label3.Text = String.Empty;
        //Label2.Text = String.Empty;

        Label4.CssClass = "lblHidden";
     
    }

    [System.Web.Services.WebMethodAttribute(), System.Web.Script.Services.ScriptMethodAttribute()]
    public static string[] GetCompletionList(string prefixText, int count, string contextKey)
    {
          string connetionString = WebConfigurationManager.ConnectionStrings["EmailListConnectionString"].ConnectionString.ToString();
        SqlConnection cnn;
        cnn = new SqlConnection(connetionString);

        cnn.Open();

        string queryString = "Select List from Lists";
        SqlDataAdapter adapter = new SqlDataAdapter(queryString, cnn);

        DataSet listName= new DataSet();
        adapter.Fill(listName, "Lists");

        cnn.Close();


        string[] emailListName = new string[listName.Tables[0].Rows.Count];
        int i = 0;
        foreach (DataRow dr in listName.Tables[0].Rows)
        {
            emailListName[i] = (string)dr["List"];
            i++;
        }




        return (from m in emailListName where m.StartsWith(prefixText, StringComparison.CurrentCultureIgnoreCase) select m).Take(count).ToArray();
        
    }

    [System.Web.Services.WebMethodAttribute(), System.Web.Script.Services.ScriptMethodAttribute()]
    public static string[] GetCompletionList1(string prefixText, int count, string contextKey)
    {

        string connetionString = WebConfigurationManager.ConnectionStrings["EmailListConnectionString"].ConnectionString.ToString();
        SqlConnection cnn;
        cnn = new SqlConnection(connetionString);

        cnn.Open();

        string queryString = "Select ListDescription from Lists";
        SqlDataAdapter adapter = new SqlDataAdapter(queryString, cnn);

        DataSet listDescription = new DataSet();
        adapter.Fill(listDescription, "Lists");

        cnn.Close();


        string[] emailListDescription = new string[listDescription.Tables[0].Rows.Count];
        int i = 0;
        foreach (DataRow dr in listDescription.Tables[0].Rows)
        {
            emailListDescription[i] = (string)dr["ListDescription"];
            i++;
        }




        return (from m in emailListDescription where m.StartsWith(prefixText, StringComparison.CurrentCultureIgnoreCase) select m).Take(count).ToArray();
    }
 

    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        GridView2.DataBind();
    }
    protected void LinkButton2_Command(object sender, CommandEventArgs e)
    {

        string connetionString = WebConfigurationManager.ConnectionStrings["EmailListConnectionString"].ConnectionString.ToString();
        SqlConnection cnn;
        cnn = new SqlConnection(connetionString);
        try
        {

            using (SqlCommand cmd = new SqlCommand("spDeleteList", cnn))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@List", SqlDbType.VarChar).Value = e.CommandArgument.ToString();

                cnn.Open();
                cmd.ExecuteNonQuery();
                cnn.Close();

            }

        }
        catch (Exception ex)
        {
            Label3.Text = "Error occured while deleting-->" + ex.ToString();
        }

        LinkButton2_Click(null, null);


    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        
    }

    protected void Page_Unload(object sender, EventArgs e)
    {
    }


    protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
    {
    }
    protected void List_TextChanged(object sender, EventArgs e)
    {
        /*Following Line will get rid of space from front and end of string*/
        List.Text = List.Text.Trim();
   
        GridView2.DataBind();

        if (IsPostBack)
        {
            if (GridView2.Rows.Count == 0)
            {
                Label2.Text = "No List(s) Found";
            }
            else
            {
                Label2.Text = String.Empty;
            }
        }
        

    }
    protected void List_Load(object sender, EventArgs e)
    {

    }

    public void OnDSUpdatedHandler(Object source, SqlDataSourceStatusEventArgs e)
    {

        string abcd = Session["CurrentListName"].ToString();


        if (e.Exception == null)
        {
            Label4.CssClass = "lblVisible";
            Label4.Text="List Updated";
            Session["CurrentListName"] = null;

        }
        else
        {
            e.ExceptionHandled = true;
           
           

            string connetionString = WebConfigurationManager.ConnectionStrings["EmailListConnectionString"].ConnectionString.ToString();
            SqlConnection cnn;
            cnn = new SqlConnection(connetionString);

          
            
            using (SqlCommand cmd = new SqlCommand("spCheckForDupList", cnn))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@ListVar", SqlDbType.VarChar).Value = Session["CurrentListName"].ToString();
                

                cmd.Parameters.Add("@return_value", SqlDbType.Int, 4).Direction = ParameterDirection.ReturnValue;

                cnn.Open();
                cmd.ExecuteNonQuery();
                cnn.Close();




                if (Convert.ToInt32(cmd.Parameters["@return_value"].Value) == 99)
                {

                    Label4.CssClass = "lblVisible ErrorText";
                    
                    Label4.Text = "List name already exists";

                     Session["CurrentListName"] = null;
                }
               

            
            }




        }


    
    }




    protected void GridView2_RowCommand(object sender, GridViewCommandEventArgs e)
    {

   
 
    }
    protected void GridView2_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

        
        Session["CurrentListName"] = e.NewValues["List"];
      

      
    }
    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
}