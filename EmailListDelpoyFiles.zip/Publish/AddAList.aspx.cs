﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;

[Serializable]
public partial class AddList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label5.CssClass = null;
        Label1.Visible = false;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
       
    }
    
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        LinkButton1.Visible = false;

        string connetionString = WebConfigurationManager.ConnectionStrings["EmailListConnectionString"].ConnectionString.ToString();
        SqlConnection cnn;
        cnn = new SqlConnection(connetionString);
        try
        {

            using (SqlCommand cmd = new SqlCommand("spAddListToDatabase", cnn))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@List", SqlDbType.VarChar).Value = TextBox3.Text;
                cmd.Parameters.Add("@ListDescription", SqlDbType.VarChar).Value = TextBox4.Text;

                cmd.Parameters.Add("@return_value", SqlDbType.Int, 4).Direction = ParameterDirection.ReturnValue;

                cmd.Parameters.Add("@new_identity", SqlDbType.Int, 4).Direction = ParameterDirection.Output;

                cnn.Open();
                cmd.ExecuteNonQuery();
                cnn.Close();

                /*Output Text*/
                

                if (Convert.ToInt32(cmd.Parameters["@return_value"].Value) == 0)
                {
                    Label1.Visible = false;
                    Label5.Text = "List has been Added";
                    TextBox3.Text = string.Empty;
                    TextBox4.Text = string.Empty;
                    /*assigning session variable to add associates to this list*/
                    HttpContext.Current.Session["listIdAdded"] = cmd.Parameters["@new_identity"].Value;

                    LinkButton1.Visible = true;

                }
                else if (Convert.ToInt32(cmd.Parameters["@return_value"].Value) ==99)
                {
                    Label5.Text = String.Empty; 
                      Label1.Visible = true;
                }
                else
                {
                   Label5.Text = "List was not added";
                }




            }

        }
        catch (Exception ex)
        {
            Label3.Text = "<b>Error occured--></b>" + ex.ToString();
        }

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("UpdateList.aspx");
    }
}