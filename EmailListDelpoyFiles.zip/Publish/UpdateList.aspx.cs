﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

[Serializable]
public partial class UpdateList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        /*When you come from AddAList.aspx to this page following code holds your session variable for list you just added on AddAList.aspx*/
        if (HttpContext.Current.Session["listIdAdded"] != null)
        {
            DropDownList1.SelectedValue = HttpContext.Current.Session["listIdAdded"].ToString();
            HttpContext.Current.Session["listIdAdded"] = null;
        }

        lblFadeInOut.CssClass = "lblHidden";
    
    }


 
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }

    protected void DropDownList1_Init(object sender, EventArgs e)
    {
       
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        for (int i = 0; i < ListBox2.Items.Count; i++)
        {

            if (ListBox2.Items[i].Selected)
            {
                ListBox1.Items.Add(ListBox2.Items[i]);
            }
        }
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {

        var selectedIndices = ListBox1.GetSelectedIndices();

        var killList = new List<ListItem>();

        ListBox myListBox = new ListBox();

        foreach (var selIndex in selectedIndices)
        {
            killList.Add(ListBox1.Items[selIndex]);
            myListBox.Items.Add(ListBox1.Items[selIndex]);
        }


        foreach (var killMe in killList)
        {
            ListBox1.Items.Remove(killMe);
        }
     
    }

   
    protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
    {
        lblFadeInOut.CssClass = "lblVisible";
        

        String strItem = string.Empty;


        for (int i = 0; i < ListBox1.Items.Count; i++)
        {
            strItem += ListBox1.Items[i].Value + ",";

        }

        if (strItem != string.Empty)
        {
            strItem = strItem.Remove(strItem.Length - 1, 1);
        }
        else
        {
            strItem = string.Empty;
        }


        string connetionString = WebConfigurationManager.ConnectionStrings["EmailListConnectionString"].ConnectionString.ToString();
        SqlConnection cnn;
        cnn = new SqlConnection(connetionString);
        try
        {

            using (SqlCommand cmd = new SqlCommand("spListMapOperations", cnn))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@ListID", SqlDbType.VarChar).Value = DropDownList1.SelectedValue.ToString();
                cmd.Parameters.Add("@AssociateIDs", SqlDbType.VarChar).Value = strItem;

                cnn.Open();
                cmd.ExecuteNonQuery();
                cnn.Close();

                ListBox1.DataBind();
            }
        }
        catch (Exception ex)
        {
            Label5.Text = "<b>Error occured--></b>" + ex.ToString();
        }
    }
    protected void ListBox1_PreRender(object sender, EventArgs e)
    {
        for (int i = 0; i < ListBox1.Items.Count - 1; i++)
        {
            if (i % 2 == 0)
            {
                ListBox1.Items[i].Attributes.Add("style", "background-color: #F0F8FF");

            }
        }
    }
    protected void ListBox2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ListBox2_PreRender(object sender, EventArgs e)
    {
        for (int i = 0; i < ListBox2.Items.Count - 1; i++)
        {
            if (i % 2 == 0)
            {
                ListBox2.Items[i].Attributes.Add("style", "background-color: #F0F8FF");

            }
        }
    }
    protected void DropDownList1_PreRender(object sender, EventArgs e)
    {

        for (int i = 0; i < DropDownList1.Items.Count - 1; i++)
        {
            if (i % 2 != 0)
            {
                DropDownList1.Items[i].Attributes.Add("style", "background-color: #F0F8FF");


            }
        }


    }
}