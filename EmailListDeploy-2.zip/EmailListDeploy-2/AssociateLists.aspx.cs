﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Collections;
using System.Drawing;

[Serializable]
public partial class ViewAssocList : System.Web.UI.Page
{
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Label3.Text = "No Associate Selected";
        }

    
       
      

    }

 

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
    

    }

   
    protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
    {
       

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
    }
    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
        
       
       DataSet ds = new DataSet();
       SqlDataAdapter sqladp = new SqlDataAdapter();

       string connetionString = WebConfigurationManager.ConnectionStrings["EmailListConnectionString"].ConnectionString.ToString();
       SqlConnection cnn;
       cnn = new SqlConnection(connetionString);
       try
       {
          
           using (SqlCommand cmd = new SqlCommand("spGetAssociatesLists", cnn))
           {
               cmd.CommandType = CommandType.StoredProcedure;

               cmd.Parameters.Add("@AssociateID", SqlDbType.Int).Value = ListBox1.SelectedValue;
              
               cnn.Open();
               sqladp.SelectCommand = cmd;
               sqladp.Fill(ds);
               cnn.Close();
               GridView2.DataSource = ds.Tables[0];

              

               GridView2.DataBind();

              


               
           }

       }
       catch (Exception ex)
       {
           Label2.Text = "<b>Error occured--></b>" + ex.ToString();

       }


       if (IsPostBack)
       {
           if (GridView2.Rows.Count == 0)
           {
               Label3.Text = "No List(s) Found";
           }
           else
           {
               Label3.Text = String.Empty;
           }
       }

       ListBox1.Focus();
     
    }

    protected void ListBox1_Load(object sender, EventArgs e)
    {
    }
    protected void ListBox1_Init(object sender, EventArgs e)
    {
      

    }
    protected void ListBox1_PreRender(object sender, EventArgs e)
    {
        for (int i = 0; i < ListBox1.Items.Count - 1; i++)
        {
            if (i % 2 == 0)
            {
                ListBox1.Items[i].Attributes.Add("style", "background-color: #F0F8FF");
        
            }
        }
    }
    protected void GridView2_Unload(object sender, EventArgs e)
    {


     
    }
    protected void GridView2_Load(object sender, EventArgs e)
    {
      

    }
    protected void GridView2_RowCreated(object sender, GridViewRowEventArgs e)
    {
       
        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Cells[1].Width = Unit.Percentage(33);
            e.Row.Cells[1].Width = Unit.Percentage(67);
        }
    }
}