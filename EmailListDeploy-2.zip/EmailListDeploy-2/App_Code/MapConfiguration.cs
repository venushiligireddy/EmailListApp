﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AutoMapper;

/// <summary>
/// Summary description for MapConfiguration
/// </summary>
public class MapConfiguration
{
	public MapConfiguration()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public static void Configure()
    {
        //Mapper.Initialize(c =>
        //{
        //    c.CreateMap<SBIAuthenticationServices.Objects.UserInfo,SBILibrary.Objects.UserInfo>();
        //    c.CreateMap<SBIAuthenticationServices.Objects.GroupInfo,SBILibrary.Objects.GroupInfo>();
        //    c.CreateMap<SBIAuthenticationServices.Objects.BaseInfo,SBILibrary.Objects.BaseInfo>();
        //});
    }

    public static TDest MapObject<TSource, TDest>(TSource source)
    {
        return Mapper.Map<TSource, TDest>(source);
    }
}