﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using List.Library;
using System.Configuration;
using SBILibrary.Objects;
using SBILibrary.BAL;


/// <summary>
/// Summary description for BasePage
/// </summary>
public class BasePage : System.Web.UI.Page
{
    protected EmailListManager _emailListManager;        
    private SBILibraryManager _sbiLibManager;
    public BasePage()
    {
        string connString = ConfigurationManager.ConnectionStrings["EmailListConnectionString"].ConnectionString;
        _emailListManager = new EmailListManager(connString);        
        _sbiLibManager = new SBILibraryManager(connString);
    }

    public string CurrentUserName
    {
        get
        {
            string userName = Context.User.Identity.Name.ToString().Trim();
            return userName.Substring(userName.LastIndexOf(@"\") + 1);
        }
    }

    public UserInfo CurrentUserInfo
    {
        get
        {            
            UserInfo userInfo = _sbiLibManager.GetUserDetail(CurrentUserName);
            return userInfo;
        }
    }
}