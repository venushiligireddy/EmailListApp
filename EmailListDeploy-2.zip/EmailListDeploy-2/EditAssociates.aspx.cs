﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using SBILibrary.Objects;

[Serializable]
public partial class UpdateAssociate : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label3.Text = String.Empty;
        Label4.CssClass = "lblHidden";
        CurrentUserNameHiddenField.Value = CurrentUserName;
        if (!IsPostBack)
        {
            Session["DeptList"] = _emailListManager.GetAllDepartments();
        }
    }


    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }


    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

        
    }

    protected void AssociatesGridView_RowDeleting(Object sender, GridViewDeleteEventArgs e)
    {
        
    }

   
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow )
        {
            IEnumerable<DepartmentInfo> deptList = (IEnumerable<DepartmentInfo>)Session["DeptList"];
            DropDownList ddl = e.Row.FindControl("DepartmentsDropDownList") as DropDownList;
            if (ddl != null && deptList != null)
            {
                ddl.DataSource = deptList;
                ddl.DataBind();
                DataRowView drView = e.Row.DataItem as DataRowView;
                ddl.SelectedValue = drView["DeptId"].ToString();
                ddl.Attributes.Add("OnChange", "javascript:updateDeptId('#" + ddl.ClientID + "')");
            }
        }
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
       GridView1.DataBind(); 
    }
    protected void LinkButton1_Command(object sender, CommandEventArgs e)
    {
      string connetionString = WebConfigurationManager.ConnectionStrings["EmailListConnectionString"].ConnectionString.ToString();
      SqlConnection cnn;
      cnn = new SqlConnection(connetionString);
      try
      {

          using (SqlCommand cmd = new SqlCommand("spDeleteAssociate", cnn))
          {
              cmd.CommandType = CommandType.StoredProcedure;

              cmd.Parameters.Add("@Associate", SqlDbType.VarChar).Value = e.CommandArgument.ToString();
              
              cnn.Open();
              cmd.ExecuteNonQuery();
              cnn.Close();
          
          }

      }
      catch (Exception ex)
      {
          Label3.Text = "Error occured while deleting-->" + ex.ToString();
      }
      LinkButton1_Click(null, null);
    }

    [System.Web.Services.WebMethodAttribute(), System.Web.Script.Services.ScriptMethodAttribute()]
    public static string[] GetCompletionList(string prefixText, int count, string contextKey)
    {
        string connetionString = WebConfigurationManager.ConnectionStrings["EmailListConnectionString"].ConnectionString.ToString();
        SqlConnection cnn;
        cnn = new SqlConnection(connetionString);

        cnn.Open();

        string queryString = "Select FirstName from Associates";
        SqlDataAdapter adapter = new SqlDataAdapter(queryString, cnn);

        DataSet firstName = new DataSet();
        adapter.Fill(firstName, "Associates");

        cnn.Close();


        string[] assocFirstName = new string[firstName.Tables[0].Rows.Count];
        int i = 0;
        foreach (DataRow dr in firstName.Tables[0].Rows)
        {
            assocFirstName[i] = (string)dr["FirstName"];
            i++;
        }




        return (from m in assocFirstName where m.StartsWith(prefixText, StringComparison.CurrentCultureIgnoreCase) select m).Take(count).ToArray();

    }

    [System.Web.Services.WebMethodAttribute(), System.Web.Script.Services.ScriptMethodAttribute()]
    public static string[] GetCompletionList2(string prefixText, int count, string contextKey)
    {
        string connetionString = WebConfigurationManager.ConnectionStrings["EmailListConnectionString"].ConnectionString.ToString();
        SqlConnection cnn;
        cnn = new SqlConnection(connetionString);

        cnn.Open();

        string queryString = "Select LastName from Associates";
        SqlDataAdapter adapter = new SqlDataAdapter(queryString, cnn);

        DataSet lastName = new DataSet();
        adapter.Fill(lastName, "Associates");

        cnn.Close();


        string[] assocLastName = new string[lastName.Tables[0].Rows.Count];
        int i = 0;
        foreach (DataRow dr in lastName.Tables[0].Rows)
        {

            assocLastName[i] = (string)dr["LastName"];
            i++;
        }

        return (from m in assocLastName where m.StartsWith(prefixText, StringComparison.CurrentCultureIgnoreCase) select m).Take(count).ToArray();

    }

    [System.Web.Services.WebMethodAttribute(), System.Web.Script.Services.ScriptMethodAttribute()]
    public static string[] GetCompletionList3(string prefixText, int count, string contextKey)
    {
        string connetionString = WebConfigurationManager.ConnectionStrings["EmailListConnectionString"].ConnectionString.ToString();
        SqlConnection cnn;
        cnn = new SqlConnection(connetionString);

        cnn.Open();

        string queryString = "Select Email from Associates";
        SqlDataAdapter adapter = new SqlDataAdapter(queryString, cnn);

        DataSet Email = new DataSet();
        adapter.Fill(Email, "Associates");

        cnn.Close();


        string[] assocEmail = new string[Email.Tables[0].Rows.Count];
        int i = 0;
        foreach (DataRow dr in Email.Tables[0].Rows)
        {

            assocEmail[i] = (string)dr["Email"];
            i++;
        }

        return (from m in assocEmail where m.StartsWith(prefixText, StringComparison.CurrentCultureIgnoreCase) select m).Take(count).ToArray();

    }

    [System.Web.Services.WebMethodAttribute(), System.Web.Script.Services.ScriptMethodAttribute()]
    public static string[] GetCompletionList4(string prefixText, int count, string contextKey)
    {
        string connetionString = WebConfigurationManager.ConnectionStrings["EmailListConnectionString"].ConnectionString.ToString();
        SqlConnection cnn;
        cnn = new SqlConnection(connetionString);

        cnn.Open();

        string queryString = "Select ShortName from Associates";
        SqlDataAdapter adapter = new SqlDataAdapter(queryString, cnn);

        DataSet shortName = new DataSet();
        adapter.Fill(shortName, "Associates");

        cnn.Close();


        string[] assocShortName = new string[shortName.Tables[0].Rows.Count];
        int i = 0;
        foreach (DataRow dr in shortName.Tables[0].Rows)
        {

            assocShortName[i] = (string)dr["ShortName"];
            i++;
        }

        return (from m in assocShortName where m.StartsWith(prefixText, StringComparison.CurrentCultureIgnoreCase) select m).Take(count).ToArray();

    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {

    }
    protected void GridView1_Load(object sender, EventArgs e)
    {
       
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        /*Following Line will get rid of space from front and end of string*/
        TextBox1.Text = TextBox1.Text.Trim();
        
        GridView1.DataBind();

        if (IsPostBack)
        {
            if (GridView1.Rows.Count == 0)
            {
                Label2.Text = "No Associate(s) Found";
            }
            else
            {
                Label2.Text = String.Empty;
            }
        }

    }




    public void OnAssociateUpdatedHandler(Object source, SqlDataSourceStatusEventArgs e)
    {

        string abcd = Session["AssociateEmailOld"].ToString();
        string efgh = Session["AssociateEmail"].ToString();
        

        if (e.Exception == null)
        {
            Label4.CssClass = "lblVisible";
            Label4.Text = "Associate Updated";
            Session["AssociateEmail"] = null;
            Session["AssociateEmailOld"] = null;
            Session["AssociateShortName"] = null;

        }
        else
        {
            e.ExceptionHandled = true;



            string connetionString = WebConfigurationManager.ConnectionStrings["EmailListConnectionString"].ConnectionString.ToString();
            SqlConnection cnn;
            cnn = new SqlConnection(connetionString);



            using (SqlCommand cmd = new SqlCommand("spCheckDupShortNameandEmail", cnn))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@EmailVar", SqlDbType.VarChar).Value = Session["AssociateEmail"].ToString();
                cmd.Parameters.Add("@EmailVarOld", SqlDbType.VarChar).Value = Session["AssociateEmailOld"].ToString();
                cmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = Session["AssociateShortName"].ToString();


                cmd.Parameters.Add("@return_value", SqlDbType.Int, 4).Direction = ParameterDirection.ReturnValue;

                cnn.Open();
                cmd.ExecuteNonQuery();
                cnn.Close();

                
                if (Convert.ToInt32(cmd.Parameters["@return_value"].Value) == 99)
                {

                    Label4.CssClass = "lblVisible ErrorText";
                    Label4.Text = "Short Name already exists";
                    Session["AssociateEmail"] = null;
                    Session["AssociateEmailOld"] = null;
                    Session["AssociateShortName"] = null;
                }
                else if (Convert.ToInt32(cmd.Parameters["@return_value"].Value) == 100)
                {

                    Label4.CssClass = "lblVisible ErrorText";
                    Label4.Text = "Email already exists";
                    Session["AssociateEmail"] = null;
                    Session["AssociateEmailOld"] = null;
                    Session["AssociateShortName"] = null;
                }
                else if (Convert.ToInt32(cmd.Parameters["@return_value"].Value) == 101)
                {

                    Label4.CssClass = "lblVisible ErrorText";
                    Label4.Text = "Email and Short Name already exist";
                    Session["AssociateEmail"] = null;
                    Session["AssociateEmailOld"] = null;
                    Session["AssociateShortName"] = null;
                }
             

            }




        }



    }



    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        //GridView1.Rows[0].Cells[1].
        int associateId = Convert.ToInt32(GridView1.Rows[e.RowIndex].Cells[2].Text);
        string email = (string)e.NewValues["Email"];
        string shortName = (string)e.NewValues["ShortName"];
        string userName = (string)e.NewValues["UserName"];
        if (!String.IsNullOrEmpty(email) && !String.IsNullOrEmpty(shortName) && !String.IsNullOrEmpty(userName))
        {
            Output result = _emailListManager.ValidateAssociateDetails(associateId, email, shortName, userName);
            if (result == Output.Failed)
            {
                Label4.CssClass = "lblVisible ErrorText";
                Label4.Text = "Error occured";                
            }
            else if (result == Output.EmailAlreadyExist)
            {
                Label4.CssClass = "lblVisible ErrorText";
                Label4.Text = "Email already exists";
            }
            else if (result == Output.ShortNameAlreadyExist)
            {
                Label4.CssClass = "lblVisible ErrorText";
                Label4.Text = "ShortName already exists";
            }
            else if (result == Output.AlreadyExist)
            {
                Label4.CssClass = "lblVisible ErrorText";
                Label4.Text = "UserName already exists";
            }

            if (result != Output.Success)
                e.Cancel = true;

            Session["AssociateEmail"] = e.NewValues["Email"];
            Session["AssociateEmailOld"] = e.OldValues["Email"];
            Session["AssociateShortName"] = e.NewValues["ShortName"];
        }

    }
}