﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SBILibrary.Objects;
using System.Data;
using System.Configuration;

public partial class AddApplication : BasePage
{    
    protected void Page_Init(object sender, EventArgs e)
    {
        
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        Label headerLabel = this.Master.FindControl("lblPageTitle") as Label;
        if (headerLabel != null)
            headerLabel.Text = "Applications";
        if (!IsPostBack)
        {
            LoadAllApplications();
        }
    }

    private void LoadAllApplications()
    {
        IEnumerable<ApplicationInfo> allApplications = _emailListManager.GetAllApplications(false);
        AppsRepeater.DataSource = allApplications;
        AppsRepeater.DataBind();
    }

    protected void AppsRepeater_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
       
    }

    protected void AppsRepeater_ItemCommand(object sender, RepeaterCommandEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {            
            LinkButton linkButton = e.Item.FindControl("AppNameLinkButton") as LinkButton;
            string dataItem = Convert.ToString(linkButton.Attributes["data-item"]);
            int appId = 0;
            if (int.TryParse(dataItem, out appId))
            {
                AppHeaderLiteral.Text = "Edit Application";
                AppIdHiddenField.Value = appId.ToString();
                ApplicationInfo appInfo = _emailListManager.GetApplicationDetails(appId);
                AppNameTextBox.Text = appInfo.Name;
                AppKeyTextBox.Text = appInfo.AppKey;
                AppDescTextBox.Text = appInfo.Description;
                IsActiveCheckBox.Checked = appInfo.IsEnabled;    
            }
            
            ScriptManager.RegisterStartupScript(this, this.GetType(), "button_click", "showAppModal();", true);
        }
    }

    protected void SaveAppButton_Click(object sender, EventArgs e)
    {
        Output result;
        ApplicationInfo appInfo = new ApplicationInfo();
        appInfo.Name = AppNameTextBox.Text;
        appInfo.AppKey = AppKeyTextBox.Text.ToUpper();
        appInfo.Description = AppDescTextBox.Text;
        appInfo.CreatedBy = CurrentUserName;
        appInfo.IsEnabled = IsActiveCheckBox.Checked;
        if (!String.IsNullOrEmpty(AppIdHiddenField.Value))
        {
            // perform update operation.
            appInfo.AppId = Convert.ToInt32(AppIdHiddenField.Value);
            appInfo.ModifiedBy = CurrentUserName;
            result = _emailListManager.UpdateApplication(appInfo);
        }
        else
        {
             result = _emailListManager.InsertApplication(appInfo);            
        }
        
        if (result == Output.Success)        
            MessageHiddenField.Value = String.Empty;                    
        else if (result == Output.AlreadyExist)        
            MessageHiddenField.Value = "This Application KEY is not available";                    
        else if (result == Output.Failed)        
            MessageHiddenField.Value = "Oops.. Some error occured, please try again.";                    

        if (!String.IsNullOrEmpty(MessageHiddenField.Value))
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "button_click", "showAppModal();", true);
        }
        else
        {
            LoadAllApplications();
            CancelButton_Click(sender, e);
        }
    }

    protected void CancelButton_Click(object sender, EventArgs e)
    {
        AppHeaderLiteral.Text = "Add Application";
        AppIdHiddenField.Value = String.Empty;
        AppNameTextBox.Text = String.Empty;
        AppDescTextBox.Text = String.Empty;
        AppKeyTextBox.Text = String.Empty;
        IsActiveCheckBox.Checked = false;
        MessageHiddenField.Value = String.Empty; 
        ScriptManager.RegisterStartupScript(this, this.GetType(), "button_click2", "closeAppModal();", true);
    }   
}